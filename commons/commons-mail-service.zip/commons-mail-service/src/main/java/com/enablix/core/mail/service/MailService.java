package com.enablix.core.mail.service;

public interface MailService {
	public boolean sendHtmlEmail(Object objectToBeMerged, String elementName, String templateName, String toMailAddress, String fromMailAddress, String subject);
}
