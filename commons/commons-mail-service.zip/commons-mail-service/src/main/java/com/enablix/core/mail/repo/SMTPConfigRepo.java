package com.enablix.core.mail.repo;

import com.enablix.core.mongo.repository.BaseMongoRepository;

public interface SMTPConfigRepo extends BaseMongoRepository<SMTPConfiguration> {

	SMTPConfiguration findByIdentity(String identity);
}
