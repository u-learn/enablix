package com.enablix.core.mail.constant;

public class MailContant {
	
	public static final String FROM_MAIL_ADDRESS="john.wakad@gmail.com";
	public static final String DEFAULT_SUBJECT="IMP MAIL FROM ADMIN";
	
}
