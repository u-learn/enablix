package com.enablix.core.mail.utility;

import java.util.Properties;
import javax.mail.Session;
import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;

import org.slf4j.LoggerFactory;

public class MailUtility {

	private final static org.slf4j.Logger logger = LoggerFactory.getLogger(MailUtility.class);

	public static boolean sendEmail(String sendFromEmail, String sendToEmail,String subject, String htmlBody) {
		
		logger.info("sending mail..");
		
		 Properties props = new Properties();
	        props.put("mail.smtp.host", "smtp.gmail.com");
	        props.put("mail.smtp.port","587");
	        props.put("mail.smtp.user","demo@gmail.com");
	        props.put("password","demo123");
	        props.put("mail.smtp.auth","true");
	        props.put("mail.transport.protocol","smtp");
	        props.put("mail.smtp.starttls.enable", "true");
	
	        
	        Session session = Session.getDefaultInstance(props, new Authenticator() {
	            @Override
	            protected PasswordAuthentication getPasswordAuthentication() {
	                String username = "demo@gmail.com";
	                String password = "demo123";
	                return new PasswordAuthentication(username,password); 
	            }
	        });
 
        try {
            Message msg = new MimeMessage(session);
          
            msg.setFrom(new InternetAddress("info@enablix.com"));
           
            msg.addRecipient(Message.RecipientType.TO, new InternetAddress(sendToEmail));
            msg.setSubject(subject);
            Multipart multipart = new MimeMultipart();
            MimeBodyPart htmlPart = new MimeBodyPart();
            htmlPart.setContent(htmlBody, "text/html");
            multipart.addBodyPart(htmlPart);
            msg.setContent(multipart);
            Transport.send(msg);
            return true;
        } catch (AddressException e) {
        	logger.error(e.getMessage(), e);
            return false;
        } catch (MessagingException e) {
        	logger.error(e.getMessage(), e);
            return false;
        }
    }
}
